/**
 * 飞书应用配置文件
 * 
 * ⚠️ 此文件包含敏感信息，请勿提交到 Git
 * ⚠️ 此文件已被添加到 .gitignore
 */

const FEISHU_CONFIG = {
  // 飞书应用凭证
  appId: 'cli_aa8a2b3862b8dbed',
  appSecret: '046Vs7hIbj5aLLGdLRY5ndAcGyI3gBIk',
  
  // 多维表格信息
  baseToken: 'Xg16bELkqa2u68s2qsvcay2LnJf',
  tableId: 'tblRO6MoUQWRh2Br',        // 订单表 ID（已自动设置）
  configTableId: 'tblKaIV13Ciph2KH',     // 配置表 ID（已自动设置）
  
  // API 端点
  apiEndpoint: 'https://open.feishu.cn/open-apis'
};

// 导出配置（兼容浏览器环境）
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FEISHU_CONFIG;
}
